# NetworkFileTransfer
This is a Qt network file transfer project with client and server side to learn Qt programming.
