/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Server/widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[18];
    char stringdata0[253];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Widget"
QT_MOC_LITERAL(1, 7, 24), // "closeClientConnectSignal"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 17), // "disconnectCommand"
QT_MOC_LITERAL(4, 51, 21), // "clientDiconnectSignal"
QT_MOC_LITERAL(5, 73, 2), // "ID"
QT_MOC_LITERAL(6, 76, 17), // "getFileListSignal"
QT_MOC_LITERAL(7, 94, 8), // "filelist"
QT_MOC_LITERAL(8, 103, 14), // "sendFileSignal"
QT_MOC_LITERAL(9, 118, 8), // "filename"
QT_MOC_LITERAL(10, 127, 19), // "addClientIPTGUISlot"
QT_MOC_LITERAL(11, 147, 3), // "CIP"
QT_MOC_LITERAL(12, 151, 5), // "state"
QT_MOC_LITERAL(13, 157, 22), // "closeClientConnectSlot"
QT_MOC_LITERAL(14, 180, 13), // "addFilePBSlot"
QT_MOC_LITERAL(15, 194, 18), // "deleteFileListItem"
QT_MOC_LITERAL(16, 213, 17), // "doubleClickedItem"
QT_MOC_LITERAL(17, 231, 21) // "fileTranferButtonSlot"

    },
    "Widget\0closeClientConnectSignal\0\0"
    "disconnectCommand\0clientDiconnectSignal\0"
    "ID\0getFileListSignal\0filelist\0"
    "sendFileSignal\0filename\0addClientIPTGUISlot\0"
    "CIP\0state\0closeClientConnectSlot\0"
    "addFilePBSlot\0deleteFileListItem\0"
    "doubleClickedItem\0fileTranferButtonSlot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   64,    2, 0x06 /* Public */,
       4,    1,   67,    2, 0x06 /* Public */,
       6,    1,   70,    2, 0x06 /* Public */,
       8,    1,   73,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    3,   76,    2, 0x0a /* Public */,
      13,    1,   83,    2, 0x0a /* Public */,
      14,    0,   86,    2, 0x0a /* Public */,
      15,    0,   87,    2, 0x0a /* Public */,
      16,    0,   88,    2, 0x0a /* Public */,
      17,    0,   89,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    9,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int,   11,    5,   12,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Widget *_t = static_cast<Widget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->closeClientConnectSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->clientDiconnectSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->getFileListSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->sendFileSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->addClientIPTGUISlot((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 5: _t->closeClientConnectSlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->addFilePBSlot(); break;
        case 7: _t->deleteFileListItem(); break;
        case 8: _t->doubleClickedItem(); break;
        case 9: _t->fileTranferButtonSlot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Widget::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::closeClientConnectSignal)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::clientDiconnectSignal)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::getFileListSignal)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Widget::sendFileSignal)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject Widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Widget.data,
      qt_meta_data_Widget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(const_cast< Widget*>(this));
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Widget::closeClientConnectSignal(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Widget::clientDiconnectSignal(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Widget::getFileListSignal(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Widget::sendFileSignal(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
