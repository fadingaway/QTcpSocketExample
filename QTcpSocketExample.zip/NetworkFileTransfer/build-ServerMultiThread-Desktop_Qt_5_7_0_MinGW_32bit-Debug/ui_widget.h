/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *label_5;
    QVBoxLayout *verticalLayout_2;
    QSplitter *splitter;
    QLabel *ClientIP1;
    QLabel *LBDisplayIP1;
    QLabel *label;
    QLabel *LBstate1;
    QPushButton *ClientPB1;
    QSplitter *splitter_2;
    QLabel *ClientIP2;
    QLabel *LBDisplayIP2;
    QLabel *label_2;
    QLabel *LBstate2;
    QPushButton *ClientPB2;
    QSplitter *splitter_3;
    QLabel *ClientIP3;
    QLabel *LBDisplayIP3;
    QLabel *label_3;
    QLabel *LBstate3;
    QPushButton *ClientPB3;
    QLabel *label_4;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *AddFilePB;
    QPushButton *DelFilePB;
    QListWidget *listWidget;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(480, 463);
        gridLayout_2 = new QGridLayout(Widget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_5 = new QLabel(Widget);
        label_5->setObjectName(QStringLiteral("label_5"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);

        gridLayout->addWidget(label_5, 0, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(7);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        splitter = new QSplitter(Widget);
        splitter->setObjectName(QStringLiteral("splitter"));
        sizePolicy.setHeightForWidth(splitter->sizePolicy().hasHeightForWidth());
        splitter->setSizePolicy(sizePolicy);
        splitter->setFrameShape(QFrame::Box);
        splitter->setFrameShadow(QFrame::Sunken);
        splitter->setOrientation(Qt::Horizontal);
        ClientIP1 = new QLabel(splitter);
        ClientIP1->setObjectName(QStringLiteral("ClientIP1"));
        sizePolicy.setHeightForWidth(ClientIP1->sizePolicy().hasHeightForWidth());
        ClientIP1->setSizePolicy(sizePolicy);
        splitter->addWidget(ClientIP1);
        LBDisplayIP1 = new QLabel(splitter);
        LBDisplayIP1->setObjectName(QStringLiteral("LBDisplayIP1"));
        sizePolicy.setHeightForWidth(LBDisplayIP1->sizePolicy().hasHeightForWidth());
        LBDisplayIP1->setSizePolicy(sizePolicy);
        LBDisplayIP1->setMinimumSize(QSize(124, 0));
        splitter->addWidget(LBDisplayIP1);
        label = new QLabel(splitter);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setFrameShape(QFrame::NoFrame);
        splitter->addWidget(label);
        LBstate1 = new QLabel(splitter);
        LBstate1->setObjectName(QStringLiteral("LBstate1"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(LBstate1->sizePolicy().hasHeightForWidth());
        LBstate1->setSizePolicy(sizePolicy1);
        splitter->addWidget(LBstate1);
        ClientPB1 = new QPushButton(splitter);
        ClientPB1->setObjectName(QStringLiteral("ClientPB1"));
        sizePolicy.setHeightForWidth(ClientPB1->sizePolicy().hasHeightForWidth());
        ClientPB1->setSizePolicy(sizePolicy);
        splitter->addWidget(ClientPB1);

        verticalLayout_2->addWidget(splitter);

        splitter_2 = new QSplitter(Widget);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        sizePolicy.setHeightForWidth(splitter_2->sizePolicy().hasHeightForWidth());
        splitter_2->setSizePolicy(sizePolicy);
        splitter_2->setFrameShape(QFrame::Box);
        splitter_2->setFrameShadow(QFrame::Sunken);
        splitter_2->setOrientation(Qt::Horizontal);
        ClientIP2 = new QLabel(splitter_2);
        ClientIP2->setObjectName(QStringLiteral("ClientIP2"));
        sizePolicy.setHeightForWidth(ClientIP2->sizePolicy().hasHeightForWidth());
        ClientIP2->setSizePolicy(sizePolicy);
        splitter_2->addWidget(ClientIP2);
        LBDisplayIP2 = new QLabel(splitter_2);
        LBDisplayIP2->setObjectName(QStringLiteral("LBDisplayIP2"));
        sizePolicy.setHeightForWidth(LBDisplayIP2->sizePolicy().hasHeightForWidth());
        LBDisplayIP2->setSizePolicy(sizePolicy);
        LBDisplayIP2->setMinimumSize(QSize(124, 0));
        splitter_2->addWidget(LBDisplayIP2);
        label_2 = new QLabel(splitter_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        splitter_2->addWidget(label_2);
        LBstate2 = new QLabel(splitter_2);
        LBstate2->setObjectName(QStringLiteral("LBstate2"));
        sizePolicy1.setHeightForWidth(LBstate2->sizePolicy().hasHeightForWidth());
        LBstate2->setSizePolicy(sizePolicy1);
        splitter_2->addWidget(LBstate2);
        ClientPB2 = new QPushButton(splitter_2);
        ClientPB2->setObjectName(QStringLiteral("ClientPB2"));
        sizePolicy.setHeightForWidth(ClientPB2->sizePolicy().hasHeightForWidth());
        ClientPB2->setSizePolicy(sizePolicy);
        splitter_2->addWidget(ClientPB2);

        verticalLayout_2->addWidget(splitter_2);

        splitter_3 = new QSplitter(Widget);
        splitter_3->setObjectName(QStringLiteral("splitter_3"));
        sizePolicy.setHeightForWidth(splitter_3->sizePolicy().hasHeightForWidth());
        splitter_3->setSizePolicy(sizePolicy);
        splitter_3->setFrameShape(QFrame::Box);
        splitter_3->setFrameShadow(QFrame::Sunken);
        splitter_3->setOrientation(Qt::Horizontal);
        ClientIP3 = new QLabel(splitter_3);
        ClientIP3->setObjectName(QStringLiteral("ClientIP3"));
        sizePolicy.setHeightForWidth(ClientIP3->sizePolicy().hasHeightForWidth());
        ClientIP3->setSizePolicy(sizePolicy);
        splitter_3->addWidget(ClientIP3);
        LBDisplayIP3 = new QLabel(splitter_3);
        LBDisplayIP3->setObjectName(QStringLiteral("LBDisplayIP3"));
        sizePolicy.setHeightForWidth(LBDisplayIP3->sizePolicy().hasHeightForWidth());
        LBDisplayIP3->setSizePolicy(sizePolicy);
        LBDisplayIP3->setMinimumSize(QSize(124, 0));
        splitter_3->addWidget(LBDisplayIP3);
        label_3 = new QLabel(splitter_3);
        label_3->setObjectName(QStringLiteral("label_3"));
        sizePolicy1.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy1);
        splitter_3->addWidget(label_3);
        LBstate3 = new QLabel(splitter_3);
        LBstate3->setObjectName(QStringLiteral("LBstate3"));
        sizePolicy.setHeightForWidth(LBstate3->sizePolicy().hasHeightForWidth());
        LBstate3->setSizePolicy(sizePolicy);
        splitter_3->addWidget(LBstate3);
        ClientPB3 = new QPushButton(splitter_3);
        ClientPB3->setObjectName(QStringLiteral("ClientPB3"));
        sizePolicy.setHeightForWidth(ClientPB3->sizePolicy().hasHeightForWidth());
        ClientPB3->setSizePolicy(sizePolicy);
        splitter_3->addWidget(ClientPB3);

        verticalLayout_2->addWidget(splitter_3);


        gridLayout->addLayout(verticalLayout_2, 1, 0, 1, 1);

        label_4 = new QLabel(Widget);
        label_4->setObjectName(QStringLiteral("label_4"));
        sizePolicy.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy);

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        AddFilePB = new QPushButton(Widget);
        AddFilePB->setObjectName(QStringLiteral("AddFilePB"));

        horizontalLayout_4->addWidget(AddFilePB);

        DelFilePB = new QPushButton(Widget);
        DelFilePB->setObjectName(QStringLiteral("DelFilePB"));

        horizontalLayout_4->addWidget(DelFilePB);


        verticalLayout->addLayout(horizontalLayout_4);


        gridLayout->addLayout(verticalLayout, 3, 0, 1, 1);

        listWidget = new QListWidget(Widget);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        gridLayout->addWidget(listWidget, 4, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0));
        label_5->setText(QApplication::translate("Widget", "\345\256\242\346\210\267\347\253\257\347\212\266\346\200\201\357\274\232", 0));
        ClientIP1->setText(QApplication::translate("Widget", "Ip:", 0));
        LBDisplayIP1->setText(QString());
        label->setText(QApplication::translate("Widget", "\350\277\236\346\216\245\347\212\266\346\200\201\357\274\232", 0));
        LBstate1->setText(QString());
        ClientPB1->setText(QApplication::translate("Widget", "\346\226\255\345\274\200\345\256\242\346\210\267\347\253\257", 0));
        ClientIP2->setText(QApplication::translate("Widget", "Ip:", 0));
        LBDisplayIP2->setText(QString());
        label_2->setText(QApplication::translate("Widget", "\350\277\236\346\216\245\347\212\266\346\200\201\357\274\232", 0));
        LBstate2->setText(QString());
        ClientPB2->setText(QApplication::translate("Widget", "\346\226\255\345\274\200\345\256\242\346\210\267\347\253\257", 0));
        ClientIP3->setText(QApplication::translate("Widget", "Ip:", 0));
        LBDisplayIP3->setText(QString());
        label_3->setText(QApplication::translate("Widget", "\350\277\236\346\216\245\347\212\266\346\200\201\357\274\232", 0));
        LBstate3->setText(QString());
        ClientPB3->setText(QApplication::translate("Widget", "\346\226\255\345\274\200\345\256\242\346\210\267\347\253\257", 0));
        label_4->setText(QApplication::translate("Widget", "\346\226\207\344\273\266\344\277\241\346\201\257\357\274\232", 0));
        pushButton->setText(QApplication::translate("Widget", "\344\274\240\350\276\223\346\226\207\344\273\266", 0));
        AddFilePB->setText(QApplication::translate("Widget", "\346\267\273\345\212\240\346\226\207\344\273\266\345\244\271", 0));
        DelFilePB->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\346\235\241\347\233\256", 0));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
