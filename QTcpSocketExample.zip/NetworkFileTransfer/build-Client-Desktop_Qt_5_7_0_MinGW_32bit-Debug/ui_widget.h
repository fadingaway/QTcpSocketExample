/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *ClientLineEdit;
    QPushButton *ClientConnectPB;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *SynFilePtn;
    QPushButton *DownloadPB;
    QListWidget *listWidget;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(429, 471);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Widget->sizePolicy().hasHeightForWidth());
        Widget->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(Widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        ClientLineEdit = new QLineEdit(Widget);
        ClientLineEdit->setObjectName(QStringLiteral("ClientLineEdit"));

        horizontalLayout_3->addWidget(ClientLineEdit);

        ClientConnectPB = new QPushButton(Widget);
        ClientConnectPB->setObjectName(QStringLiteral("ClientConnectPB"));

        horizontalLayout_3->addWidget(ClientConnectPB);


        verticalLayout_2->addLayout(horizontalLayout_3);

        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout_2->addWidget(pushButton);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        SynFilePtn = new QPushButton(Widget);
        SynFilePtn->setObjectName(QStringLiteral("SynFilePtn"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(SynFilePtn->sizePolicy().hasHeightForWidth());
        SynFilePtn->setSizePolicy(sizePolicy1);

        horizontalLayout_4->addWidget(SynFilePtn);

        DownloadPB = new QPushButton(Widget);
        DownloadPB->setObjectName(QStringLiteral("DownloadPB"));
        sizePolicy1.setHeightForWidth(DownloadPB->sizePolicy().hasHeightForWidth());
        DownloadPB->setSizePolicy(sizePolicy1);

        horizontalLayout_4->addWidget(DownloadPB);


        verticalLayout_2->addLayout(horizontalLayout_4);


        verticalLayout->addLayout(verticalLayout_2);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        listWidget = new QListWidget(Widget);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        gridLayout->addWidget(listWidget, 1, 0, 1, 1);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0));
        ClientConnectPB->setText(QApplication::translate("Widget", "\350\277\236\346\216\245/\346\226\255\345\274\200", 0));
        pushButton->setText(QApplication::translate("Widget", "\344\270\212\344\274\240\346\226\207\344\273\266", 0));
        SynFilePtn->setText(QApplication::translate("Widget", "\345\220\214\346\255\245\346\226\207\344\273\266\345\210\227\350\241\250", 0));
        DownloadPB->setText(QApplication::translate("Widget", "\344\270\213\350\275\275", 0));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
